class H{
	public static void main(String[] args){
		int num = 90;
		int sum = 0;
		while(num>=11){
			sum=sum+num;
			num--;
		}
		  System.out.println(sum);
	}
}

