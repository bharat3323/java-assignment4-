class A{
	public static void main(String[] args){
		int range = 90;
		while(range>=65){
			System.out.println((char)range);
			range--;
		}
	}
}
