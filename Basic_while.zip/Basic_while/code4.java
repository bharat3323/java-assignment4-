class D{
	public static void main(String[] args){
		int num = 10;
		while(num>=1){
			System.out.println(num*num);
			num--;
		}
	}
}
