class E{
	public static void main(String[] args){
		int day = 7;
		while(day>=0){
			if(day>=1){
				System.out.println(day+"remaining");
			}else{
				System.out.println("0 days Assignment is Overdeu");
			}
			day--;
		}
	}
}
